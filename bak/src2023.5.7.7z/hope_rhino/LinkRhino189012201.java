package hope_rhino;

// for nothing. TODO.
public class LinkRhino189012201 {
}
