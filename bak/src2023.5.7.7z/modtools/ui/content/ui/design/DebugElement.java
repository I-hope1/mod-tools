package modtools.ui.content.ui.design;

import modtools.ui.components.Window;
import modtools.ui.content.Content;

public class DebugElement extends Content {
	public DebugElement(String name) {
		super(name);
	}

	@Override
	public void load() {
	}
	public void build() {
	}
}
